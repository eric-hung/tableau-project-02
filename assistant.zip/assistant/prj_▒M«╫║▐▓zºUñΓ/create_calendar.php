<?php
$rows = "Y-m-d".PHP_EOL;
for($i=0;$i<366;$i++)
  $rows .= date('Y-m-d', strtotime(sprintf("2020-01-01 +%d day", $i))).PHP_EOL;

file_put_contents('date.csv', $rows);
