<?php

$ar_list = get_ar_list();
$new_ar_list = array();
foreach( $ar_list as $ar ){
  if( !ar_check($ar) ){
    continue;
  }
  
  if( empty($ar['prj']) ){
    $new_ar_list[] = $ar;
    continue;
  }
  
  if( empty($ar['date']) || !preg_match('/[0-9]{4}\-[0-9]{2}\-[0-9]{2}/', $ar['date'], $matches) ){
    $new_ar_list[] = $ar;
    continue;    
  }
  
  if( empty($ar['duration']) || !is_numeric($ar['duration']) ){
    $new_ar_list[] = $ar;
    continue;    
  }
  create_log($ar);
}

$cmd="move ar.json ar.json.bak";
shell_exec($cmd);

file_put_contents("ar.json", json_encode_x($new_ar_list));

/**
 *
 */
function create_log($ar){
    
}
 
/**
 *
 */
function ar_check($ar){
  
  $keys = array(
    "prj",
    "date",
    "title",
    "place",
    "participants",
    "duration"
  );
  
  foreach($keys as $key){
    if(!isset($ar))
      return false;
  }
}

/**
 *
 */
function get_ar_list(){
  $fpath = 'ar.json';
  return json_decode(file_get_contents($fpath), true);
}

/**
 *
 */
function json_encode_x($data){
  $flags = JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_FORCE_OBJECT;
  return json_encode($data, $flags);
}