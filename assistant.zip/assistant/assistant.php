<?php
/**
 *
 */
$conf = array(
  'work_dir' => 'F:',
  'empty_log_dir' => 'F:\\_empty_logs'
);

$dir = $conf['work_dir'];
if( !is_dir($dir) )
  die(sprintf('Directory \"%s\" does not exist. Check your configuration.' . PHP_EOL, $dir));

date_default_timezone_set('Asia/Taipei');

array_shift($argv);
$report = array(
  'project_directory_exception_check' => array(
    'value' =>'', 
    'default' => '[No exception found]'
  ),
  'prj_summary' => array(
    'value' =>'', 
    'default' => '',
    'output_file' => 'F:\\prj_summary.csv',
    'output_flag' => true
  ),
  'log_summary' => array(
    'value' =>'', 
    'default' => '',
    'output_file' => 'F:\\log_summary.csv',
    'output_flag' => true
  )
);

$cwd = getcwd();
chdir($dir);

$prjs = get_prjs();

$report['prj_summary']['value'] = sprintf('"%s","%s","%s","%s","%s","%s","%s","%s","%s","%s"'.PHP_EOL, 'name', 'type', 'state', 'importance', 'deadline', 'estimation', 'sum_duration', 'remain_hours', 'remain_days', 'urgency');
$report['log_summary']['value'] = sprintf('"%s","%s","%s","%s","%s","%s","%s"'.PHP_EOL, 'name', 'prj_state', 'date', 'title', 'state_head', 'state_body', 'duration');
foreach($prjs as $prj){
  
  $report['prj_summary']['value'] .= sprintf('"%s","%s","%s",%.3f,"%s",%.3f,%.3f,%.3f,%.3f,%.3f'.PHP_EOL, $prj['name'], $prj['type'], $prj['state'], $prj['importance'], $prj['deadline'], $prj['estimation'], $prj['sum_duration'], $prj['remain_hours'], $prj['remain_days'], $prj['urgency']);
  
  //異常檢查: 是否缺對應的目錄?
  if( !is_dir($prj['dir'].'\\'.$prj['name']) )
    $report['project_directory_exception_check']['value'] .= sprintf("Exception: Project directory \"%s\" does not exist." . PHP_EOL, $prj['name']);
  
  //輸出工作記錄摘要, 搬移前一天的空日誌  
  $today = date('Y-m-d');
  foreach($prj['logs'] as $date => $log){
    //搬移前n天(n>0)的空日誌到合適的目錄去:
    if($date < $today && $log['state']['head']=='empty' && $log['state']['body']=='empty'){
      $cmd = sprintf("move /Y %s %s\\", get_log_path($prj, $date), $conf['empty_log_dir']);
      echo $cmd.PHP_EOL;
      shell_exec($cmd);
    }
    
    //輸出工作記錄摘要:
    $h = &$log['head'];
    $s = &$log['state'];
    $report['log_summary']['value'] .= sprintf('"%s","%s","%s","%s","%s","%s","%s"'.PHP_EOL, $prj['name'], $prj['state'], $h['date'], $h['title'], $s['head'], $s['body'], $h['duration']);
  }
}

/**
 * output
 */
foreach($report as $k => $v){
  if( explode("_", $k)[1] == 'summary' ){
    if($v['output_flag'])
      file_put_contents($v['output_file'], $v['value']);
    continue;
  }  
  echo date('Y-m-d H:i:s').PHP_EOL;
  printf("-- %s --" . PHP_EOL, $k);
  echo empty($v['value']) ? $v['default'] : $v['value'];
  echo PHP_EOL;
}

//結束前返回工作前的位置
chdir($cwd);

//--------------------------------------------------------------------------------------

/**
 *
 */
function get_prjs(){

  $section_dirs = array(
    'active' => __DIR__,
    'closed' => __DIR__ . '/_closed'
  );
  
  $cwd = getcwd();
  
  $prjs = array();
  foreach($section_dirs as $prj_state => $sec_dir):
    
    chdir($sec_dir);
    $prj_profile_lst = load_prj_profiles();
    foreach($prj_profile_lst as $prj_profile){
      
      $prj_name = $prj_profile['name'];
      
      //對於進行中的專案, 建立日誌檔樣板(若今天日誌檔不存在的話)
      if( $prj_state=='active' ){
        create_day_log($prj_profile);
      }
      
      $prjs[$prj_name] = $prj_profile;
      $prj = &$prjs[$prj_name];
      if(empty($prj)){
        die("Error found: the profile of " . $prj_name . " doesn't exist." . PHP_EOL);
      }
      $prj = array_merge($prj, array(
        'state' => $prj_state,
        'dir' => $sec_dir,
        'logs' => array()
      ));
      
      $cmd = sprintf("dir %s\\%s_*.txt /b > logs.lst 2>null", $prj['name'], $prj['name']);
      shell_exec($cmd);
      //$prj_log_files = explode("\n", rtrim(shell_exec($cmd)));
      $prj_log_files = file('logs.lst', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
      if(count($prj_log_files)==0){
        printf("\"%s\": No log files found.".PHP_EOL,$cmd);
      }
      foreach($prj_log_files as $prj_log_file){
        preg_match('/([0-9]{4}\-[0-9]{2}\-[0-9]{2})/', $prj_log_file, $mt);
        //print_r($mt);
        if(empty($mt[1]))
          continue;      
        $date = $mt[1];
        
        $fpath = sprintf("%s\\%s", $prj['name'], $prj_log_file);      
        $lines = file($fpath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $prj['logs'][$date]['head'] = array(
          'date' => '',
          'title' => '',
          'place' => '',
          'participants' => '',
          'duration' => ''
        );
        
        $dlog = &$prj['logs'][$date];
        $dlog['state'] = array(
          'head' => 'empty',
          'body' => 'empty'
        );
        if( count($dlog['head']) < count($lines) ) {
          $dlog['state']['body'] = 'written';
        }
        for($i=0; $i<count($dlog['head']); $i++){
          $kv = explode(":", $lines[$i]);
          $key = trim($kv[0]);
          
          //出現不在定義以內的表頭欄位, 標記[注意]
          if(!isset($dlog['head'][$key])){
            $dlog['state']['head'] = 'notice';
            continue;
          }
          
          //任何[非日期欄位]有填值的話, head狀態則更新為[已寫]
          if( $key != 'date' && !empty(trim($kv[1])) && $dlog['state']['head'] == 'empty'){
            $dlog['state']['head'] = 'written';
          }
          
          $dlog['head'][$key] = head_data_sanitize($kv[0], $kv[1]);
        }
        sum_duration($prj);
      }
      estimate_importance($prj);
      estimate_urgency($prj);
    }
  endforeach;
  //print_r($prjs);exit;

  chdir($cwd);

  return $prjs;
}  
 
//---------------------------------------------------------------------------------
/**
 *
 */
function estimate_importance(&$prj){
  
  //已結案的重要性降為0
  if($prj['state'] == 'closed'){
    $prj['importance'] = 0;
    return;
  }
  
  $factor = pow(1.1, round($prj['sum_duration'] / 6));
  
  $prj['importance'] *= $factor;
  
  if( $prj['importance'] >1 )
    $prj['importance'] = 1;
}

/**
 *
 */
function estimate_urgency(&$prj){

  $work_hours_a_day = 8;
  $today = date('Y-m-d');
  
  // urgency degree: [0, 1], 0 is default.
  $prj['urgency'] = 0;
    
  $deadline = $prj['deadline'];
  if( $deadline == 'today'){
    $deadline = $today;
    $prj['deadline'] = $deadline;
  }elseif( preg_match('/\+?([0-9]+)/', $deadline, $mt) ){
    $days = $mt[1];
    $deadline = date('Y-m-d', strtotime(' + ' . $days . ' days'));
    $prj['deadline'] = $deadline;
  }elseif(empty($deadline)){
    $prj['deadline'] = date('Y-m-d', strtotime(' + ' . 30 . ' days'));
  }

  // projects in closed should be assigned with min urgency.
  if($prj['state'] == 'closed'){
    return;    
  }

  // remain days between today and deadline
  $remain_days = round((strtotime($deadline) - strtotime($today)) / 86400, 3);
  $prj['remain_days'] = $remain_days;
  
  // to calc how many work hours required to finish the project?
  if(empty($prj['estimation']))
    $prj['estimation'] = $remain_days * ($work_hours_a_day * 0.125);
  
  //2020-10-13: new idea implement. '+' sign means that the estimation is increamential, not total. 
  if( substr($prj['estimation'],0,1)=='+' )
    $prj['estimation'] += $prj['sum_duration'];
    
  $remain_hours = $prj['estimation'] - $prj['sum_duration'];
  $prj['remain_hours'] = $remain_hours;
  

  // expired projects should be assigned with max urgency
  if($remain_days <= 0) {
    $prj['urgency'] = 1.25;
    return; 
  }
  
  if ($remain_hours <= 0) {
    $prj['urgency'] = 1.25;
    return;     
  }
      
  $prj['urgency'] = $remain_hours / ($remain_days * $work_hours_a_day);
  
}
 
/** 
 *
 */
function sum_duration(&$prj){
  $prj['sum_duration'] = 0;
  foreach($prj['logs'] as $Ymd => $log){
    $prj['sum_duration'] += empty($log['head']['duration']) ? 0 : $log['head']['duration'];
  }
}
 
/**
 *
 */ 
function head_data_sanitize($key, $value){
  $value = trim($value);
  if($key=='date'){
    $value = explode(' ', $value)[0];
  }
    
  return $value;
}

/**
 * 根據專案名稱以及指定日期, 建立工作記錄樣板檔.
 */
function create_day_log($prj, $Ymd = null){
    
  if(empty($Ymd))
    $Ymd = date('Y-m-d');

  $target_path = get_log_path($prj, $Ymd);

  if( !is_file($target_path) )
    file_put_contents($target_path, init_content($Ymd));
}

/**
 *
 */
function get_log_path($prj, $Ymd){

  $log_path = sprintf("%s\\%s\\%s_%s.txt", $prj['dir'], $prj['name'], $prj['name'], $Ymd);
  return $log_path;
}
 
/**
 * 工作記錄樣板檔內容初始化: 新增一些必要欄位
 */
function init_content($Ymd = null){
  if(empty($Ymd))
    $Ymd = date('Y-m-d');
  
  $day = date('D', strtotime($Ymd));
  
  $cnt =  sprintf("date: %s [%s]", $Ymd, $day) . PHP_EOL;
  $cnt .= sprintf("title: ") . PHP_EOL;
  $cnt .= sprintf("place: ") . PHP_EOL;
  $cnt .= sprintf("participants: ") . PHP_EOL;
  $cnt .= sprintf("duration: ") . PHP_EOL;
  $cnt .= PHP_EOL;
  return $cnt;
}

/**
 *
 */
function load_prj_profiles(){
  $head = array(
    'name',
    'type',
    'importance',
    'deadline',
    'estimation'
  );
  
  $cmd = sprintf("dir prj_*.txt /b");
  $prj_profile_lst = explode("\n", rtrim(shell_exec($cmd)));

  $prjs = array();
  foreach($prj_profile_lst as $prj_profile){
    $prj_name = str_replace('.txt', '', $prj_profile);
    $prjs[$prj_name] = array();
    $lines = file($prj_profile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    for($i=0; $i<count($head); $i++){
      $kv = explode(":", $lines[$i]);
      $key = trim($kv[0]);
      $value = trim($kv[1]);
      $prjs[$prj_name][$key] = $value;
    }
  }

  return $prjs;
}
